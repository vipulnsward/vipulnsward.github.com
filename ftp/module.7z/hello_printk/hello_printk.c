/*
 * "Hello, world!" minimal kernel module
 *
 *vipulnsward<insert at here>gmail <insert dot here> com
 */

/*
 * Below are header files provided by the kernel which are
 * required for all modules.  They include things like the definition
 * of the module_init() macro.
 */
#include <linux/init.h>
#include <linux/module.h>

/*
 * This is the init function, which is run when the module is first
 * loaded.  The __init keyword tells the kernel that this code will
 * only be run once, when the module is loaded.
 */

static int __init
hello_init(void)
{
	printk("Hello, world!\n");
	return 0;
}

/*
 * The below macro informs the kernel as to which function to use as
 * the init function.
 */

module_init(hello_init);

/*
 * Similary, the exit function is run once, upon module unloading, and
 * the module_exit() macro identifies which function is the exit
 * function.
 */

static void __exit
hello_exit(void)
{
	printk("Goodbye, world!\n");
}

module_exit(hello_exit);


MODULE_LICENSE("GPL");
MODULE_AUTHOR("Vipul A M(vipulnsward<insert at here>gmail <insert dot here> com)");
MODULE_DESCRIPTION("\"Hello, world!\" minimal module");
MODULE_VERSION("printk");
